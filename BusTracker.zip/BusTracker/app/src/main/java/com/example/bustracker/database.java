package com.example.bustracker;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class database extends AppCompatActivity {

    // Declare variables
    EditText etName, etMobile, etAddress;
    Button btnSave, btnFetch; // Added btnFetch
    TextView tvDisplay;       // Added tvDisplay
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("Contacts");

        // Connect UI elements
        etName = findViewById(R.id.etName);
        etMobile = findViewById(R.id.etMobile);
        etAddress = findViewById(R.id.etAddress);
        btnSave = findViewById(R.id.btnSave);

        // Connect new UI elements
        btnFetch = findViewById(R.id.btnFetch);
        tvDisplay = findViewById(R.id.tvDisplay);

        // Save Button Listener
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });

        // Fetch Button Listener
        btnFetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchData();
            }
        });
    }

    private void saveData() {
        String name = etName.getText().toString().trim();
        String mobile = etMobile.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(mobile) || TextUtils.isEmpty(address)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = databaseReference.push().getKey();

        HashMap<String, String> contactMap = new HashMap<>();
        contactMap.put("id", id);
        contactMap.put("name", name);
        contactMap.put("mobile", mobile);
        contactMap.put("address", address);

        if (id != null) {
            databaseReference.child(id).setValue(contactMap)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(database.this, "Data Saved Successfully!", Toast.LENGTH_SHORT).show();
                        etName.setText("");
                        etMobile.setText("");
                        etAddress.setText("");
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(database.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    // --- NEW METHOD TO FETCH DATA ---
    private void fetchData() {
        // Read from the "Contacts" node
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // StringBuilder to hold all the data text
                StringBuilder stringBuilder = new StringBuilder();

                // Loop through all children (the unique IDs) in the "Contacts" node
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    // Extract data using the keys you saved
                    String name = dataSnapshot.child("name").getValue(String.class);
                    String mobile = dataSnapshot.child("mobile").getValue(String.class);
                    String address = dataSnapshot.child("address").getValue(String.class);

                    // Format the display string
                    stringBuilder.append("Name: ").append(name).append("\n");
                    stringBuilder.append("Mobile: ").append(mobile).append("\n");
                    stringBuilder.append("Address: ").append(address).append("\n\n");
                }

                // Show the result in the TextView
                tvDisplay.setText(stringBuilder.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Toast.makeText(database.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

