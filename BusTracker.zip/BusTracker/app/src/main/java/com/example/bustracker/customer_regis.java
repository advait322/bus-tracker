package com.example.bustracker;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class customer_regis extends AppCompatActivity {

    EditText nameet, mobileet, userid, custpass, comfirmpass;
    Button customer_register_button;
    DatabaseReference databaseReference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_regis);

        // --- Initialize Views ---
        nameet = findViewById(R.id.nameet);
        mobileet = findViewById(R.id.mobileet);
        userid = findViewById(R.id.userid);
        custpass = findViewById(R.id.custpass);
        comfirmpass = findViewById(R.id.comfirmpass);
        customer_register_button = findViewById(R.id.customer_register_button);

        // --- Initialize Firebase Database Reference ---
        // Get a reference to the "customer" node.
        databaseReference = FirebaseDatabase.getInstance().getReference("customer");

        // --- Set OnClickListener for the Register Button ---
        customer_register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }

    private void registerUser() {
        // --- Get User Input ---
        String name = nameet.getText().toString().trim();
        String mobile = mobileet.getText().toString().trim();
        String userIdText = userid.getText().toString().trim();
        String password = custpass.getText().toString().trim();
        String confirmPassword = comfirmpass.getText().toString().trim();

        // --- Validate Input ---
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(mobile) || TextUtils.isEmpty(userIdText) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // --- Check if Passwords Match ---
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // --- Save Data to Firebase ---
        // Create a HashMap to store user data
        HashMap<String, String> userData = new HashMap<>();
        userData.put("name", name);
        userData.put("mobile", mobile);
        userData.put("userid", userIdText);
        userData.put("password", password);

        // Use the userid as the unique key for the new user
        databaseReference.child(userIdText).setValue(userData)
                .addOnSuccessListener(aVoid -> {
                    // --- Show Success Message ---
                    Toast.makeText(customer_regis.this, "Registration Successful!", Toast.LENGTH_SHORT).show();

                    // Optional: Go back to the login screen after successful registration
                    Intent intent = new Intent(customer_regis.this, customer_login.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(customer_regis.this, "Registration Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
