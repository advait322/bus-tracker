package com.example.bustracker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.util.HashMap;
import java.util.Map;

public class host_bus_no extends AppCompatActivity {

    DatabaseReference databaseReference;

    EditText bus, bus50, bus_seri, bus0809, from_location, to_location, date;
    Button next, clearbtn;
    String userId;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_bus_no);

        userId = getIntent().getStringExtra("BATCH_NO");

        databaseReference = FirebaseDatabase.getInstance().getReference("hostdata");

        bus = findViewById(R.id.bus);
        bus50 = findViewById(R.id.bus50);
        bus_seri = findViewById(R.id.bus_seri);
        bus0809 = findViewById(R.id.bus0809);
        from_location = findViewById(R.id.from_location);
        to_location = findViewById(R.id.to_location);
        date = findViewById(R.id.date);
        next = findViewById(R.id.next);
        clearbtn = findViewById(R.id.clearbtn);

        // =========================================
        // MODERN MATERIAL TIME PICKER (ATTRACTIVE)
        // =========================================
        date.setFocusable(false);
        date.setOnClickListener(v -> {

            MaterialTimePicker picker = new MaterialTimePicker.Builder()
                    .setTimeFormat(TimeFormat.CLOCK_12H)
                    .setHour(12)
                    .setMinute(0)
                    .setTitleText("Select Travel Time")
                    .build();

            picker.show(getSupportFragmentManager(), "TIME_PICKER");

            picker.addOnPositiveButtonClickListener(view -> {

                int hour = picker.getHour();
                int minute = picker.getMinute();

                String amPm;
                int hour12;

                if (hour >= 12) {
                    amPm = "PM";
                    hour12 = hour - 12;
                } else {
                    amPm = "AM";
                    hour12 = hour;
                }

                if (hour12 == 0) {
                    hour12 = 12;
                }

                String formattedTime = String.format("%02d:%02d %s",
                        hour12, minute, amPm);

                date.setText(formattedTime);
            });
        });

        // =========================================
        // AUTO MOVE BUS NUMBER BOXES
        // =========================================

        bus.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                if (s.length() == 2) bus50.requestFocus();
            }
        });

        bus50.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                if (s.length() == 2) bus_seri.requestFocus();
            }
        });

        bus_seri.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                if (s.length() == 2) bus0809.requestFocus();
            }
        });

        bus0809.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                if (s.length() == 4) from_location.requestFocus();
            }
        });

        clearbtn.setOnClickListener(v -> clearBusData());

        next.setOnClickListener(v -> {

            String busFromInput = bus.getText().toString().trim();
            String bus50FromInput = bus50.getText().toString().trim();
            String bus_seriFromInput = bus_seri.getText().toString().trim();
            String bus0809FromInput = bus0809.getText().toString().trim();
            String from_locationFromInput = from_location.getText().toString().trim();
            String to_locationFromInput = to_location.getText().toString().trim();
            String timeFromInput = date.getText().toString().trim();

            if (!busFromInput.isEmpty() && !bus50FromInput.isEmpty() &&
                    !bus_seriFromInput.isEmpty() && !bus0809FromInput.isEmpty() &&
                    !from_locationFromInput.isEmpty() && !to_locationFromInput.isEmpty() &&
                    !timeFromInput.isEmpty()) {

                updateBusData(busFromInput, bus50FromInput, bus_seriFromInput,
                        bus0809FromInput, from_locationFromInput,
                        to_locationFromInput, timeFromInput);

            } else {
                Toast.makeText(host_bus_no.this,
                        "Please fill all fields",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateBusData(String busFromInput, String bus50FromInput,
                               String bus_seriFromInput, String bus0809FromInput,
                               String from_locationFromInput, String to_locationFromInput,
                               String timeFromInput) {

        Map<String, Object> busData = new HashMap<>();
        busData.put("bus", busFromInput);
        busData.put("bus50", bus50FromInput);
        busData.put("bus_seri", bus_seriFromInput);
        busData.put("bus0809", bus0809FromInput);
        busData.put("from_location", from_locationFromInput);
        busData.put("to_location", to_locationFromInput);
        busData.put("date", timeFromInput);  // SAVING TIME

        databaseReference.child(userId).updateChildren(busData)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Data Saved!", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(host_bus_no.this, host_map.class);
                    intent.putExtra("BATCH_NO", userId);
                    startActivity(intent);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this,
                                "Error: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }

    private void clearBusData() {

        Map<String, Object> clearedData = new HashMap<>();
        clearedData.put("bus", null);
        clearedData.put("bus50", null);
        clearedData.put("bus_seri", null);
        clearedData.put("bus0809", null);
        clearedData.put("from_location", null);
        clearedData.put("to_location", null);
        clearedData.put("date", null);

        databaseReference.child(userId).updateChildren(clearedData)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Bus details cleared.", Toast.LENGTH_SHORT).show();
                    bus.setText("");
                    bus50.setText("");
                    bus_seri.setText("");
                    bus0809.setText("");
                    from_location.setText("");
                    to_location.setText("");
                    date.setText("");
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this,
                                "Error clearing details: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }
}