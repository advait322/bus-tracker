package com.example.bustracker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.*;

public class customer_login extends AppCompatActivity {

    Button customer_login_button, customer_register_button;
    EditText userIdEt, passwordEt;
    DatabaseReference databaseReference;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 🔹 Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);

        // 🔹 If already logged in → go directly to search page
        if (sharedPreferences.getBoolean("isLoggedIn", false)) {
            Intent intent = new Intent(customer_login.this, customer_search.class);
            startActivity(intent);
            finish();
        }

        setContentView(R.layout.activity_customer_login);

        userIdEt = findViewById(R.id.nameet);
        passwordEt = findViewById(R.id.comfirmpass);
        customer_login_button = findViewById(R.id.customer_login_button);
        customer_register_button = findViewById(R.id.customer_register_button);

        databaseReference = FirebaseDatabase.getInstance().getReference("customer");

        customer_login_button.setOnClickListener(v -> loginCustomer());

        customer_register_button.setOnClickListener(v -> {
            Intent intent = new Intent(customer_login.this, customer_regis.class);
            startActivity(intent);
        });
    }

    private void loginCustomer() {

        String userIdFromInput = userIdEt.getText().toString().trim();
        String passwordFromInput = passwordEt.getText().toString().trim();

        if (TextUtils.isEmpty(userIdFromInput) || TextUtils.isEmpty(passwordFromInput)) {
            Toast.makeText(this, "Please enter User ID and Password", Toast.LENGTH_SHORT).show();
            return;
        }

        Query checkUserQuery = databaseReference
                .orderByChild("userid")
                .equalTo(userIdFromInput);

        checkUserQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {

                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {

                        String passwordFromDB =
                                userSnapshot.child("password").getValue(String.class);

                        if (passwordFromDB != null &&
                                passwordFromDB.equals(passwordFromInput)) {

                            Toast.makeText(customer_login.this,
                                    "Login Successful!",
                                    Toast.LENGTH_SHORT).show();

                            String userIdFromDB =
                                    userSnapshot.child("userid").getValue(String.class);
                            String nameFromDB =
                                    userSnapshot.child("name").getValue(String.class);
                            String mobileFromDB =
                                    userSnapshot.child("mobile").getValue(String.class);

                            // ✅ SAVE LOGIN SESSION
                            SharedPreferences.Editor editor =
                                    sharedPreferences.edit();

                            editor.putBoolean("isLoggedIn", true);
                            editor.putString("USER_ID", userIdFromDB);
                            editor.putString("NAME", nameFromDB);
                            editor.putString("MOBILE", mobileFromDB);
                            editor.apply();

                            Intent intent =
                                    new Intent(customer_login.this,
                                            customer_search.class);

                            startActivity(intent);
                            finish();
                            return;
                        }
                    }

                    Toast.makeText(customer_login.this,
                            "Invalid Credentials",
                            Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(customer_login.this,
                            "User not found",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(customer_login.this,
                        "Database Error: " + error.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}