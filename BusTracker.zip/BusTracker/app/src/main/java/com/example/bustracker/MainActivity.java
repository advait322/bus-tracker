package com.example.bustracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;   // ✅ DECLARE THIS

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ✅ Initialize SharedPreferences FIRST
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);

        // 🔥 AUTO LOGIN CHECK
        if (sharedPreferences.getBoolean("isLoggedIn", false)) {
            Intent intent = new Intent(MainActivity.this, customer_search.class);
            startActivity(intent);
            finish();   // prevent back to MainActivity
            return;     // stop executing further code
        }

        setContentView(R.layout.activity_main);

        // Buttons
        Button hostButton = findViewById(R.id.host);
        Button customerButton = findViewById(R.id.customer);

        // Host Button
        hostButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, host_login.class);
            startActivity(intent);
        });

        // Customer Button
        customerButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, customer_login.class);
            startActivity(intent);
        });
    }
}