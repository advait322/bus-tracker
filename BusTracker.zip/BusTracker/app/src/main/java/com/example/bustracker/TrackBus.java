package com.example.bustracker;

import android.animation.ValueAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class TrackBus extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Marker busMarker;

    TextView locationText;
    DatabaseReference ref;
    String busId;

    private Handler handler = new Handler();
    private Runnable locationUpdater;

    private List<LatLng> routeList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_bus);

        locationText = findViewById(R.id.locationText);

        busId = getIntent().getStringExtra("BUS_ID");

        if (busId == null) {
            Toast.makeText(this, "Bus ID is NULL", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        ref = FirebaseDatabase.getInstance()
                .getReference("hostdata")
                .child(busId);

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    // ================= MAP READY =================

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);

        loadFullRoute();
        startBusTracking();
    }

    // ================= LOAD ROUTE =================

    private void loadFullRoute() {

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (!snapshot.exists()) return;

                routeList.clear();

                try {

                    for (DataSnapshot routeSnap :
                            snapshot.child("route").getChildren()) {

                        Double lat = routeSnap.child("latitude").getValue(Double.class);
                        Double lng = routeSnap.child("longitude").getValue(Double.class);

                        if (lat != null && lng != null) {
                            routeList.add(new LatLng(lat, lng));
                        }
                    }

                    if (routeList.isEmpty()) {
                        Toast.makeText(TrackBus.this,
                                "No route points found",
                                Toast.LENGTH_LONG).show();
                        return;
                    }

                    // Draw route
                    mMap.addPolyline(new PolylineOptions()
                            .addAll(routeList)
                            .width(8f)
                            .color(android.graphics.Color.BLUE));

                    // Start Marker
                    LatLng startPoint = routeList.get(0);
                    mMap.addMarker(new MarkerOptions()
                            .position(startPoint)
                            .title("From")
                            .icon(BitmapDescriptorFactory
                                    .defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));

                    // End Marker
                    LatLng endPoint = routeList.get(routeList.size() - 1);
                    mMap.addMarker(new MarkerOptions()
                            .position(endPoint)
                            .title("To")
                            .icon(BitmapDescriptorFactory
                                    .defaultMarker(BitmapDescriptorFactory.HUE_RED)));

                    // Zoom full route
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    for (LatLng point : routeList) {
                        builder.include(point);
                    }

                    mMap.animateCamera(
                            CameraUpdateFactory.newLatLngBounds(builder.build(), 150)
                    );

                } catch (Exception e) {
                    Toast.makeText(TrackBus.this,
                            "Error loading route",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // ================= LIVE TRACKING =================

    private void startBusTracking() {

        locationUpdater = new Runnable() {
            @Override
            public void run() {

                ref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        try {

                            Double lat = snapshot.child("latitude")
                                    .getValue(Double.class);

                            Double lng = snapshot.child("longitude")
                                    .getValue(Double.class);

                            if (lat == null || lng == null) return;

                            LatLng gpsLocation = new LatLng(lat, lng);

                            // SNAP TO ROUTE
                            LatLng busLocation = getNearestPoint(gpsLocation);

                            locationText.setText(
                                    "Latitude: " + busLocation.latitude +
                                            "\nLongitude: " + busLocation.longitude
                            );

                            if (busMarker == null) {

                                busMarker = mMap.addMarker(
                                        new MarkerOptions()
                                                .position(busLocation)
                                                .title("Bus Location")
                                                .flat(true)
                                );

                            } else {

                                animateMarker(busMarker, busLocation);
                            }

                        } catch (Exception ignored) {}
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });

                handler.postDelayed(this, 1000);
            }
        };

        handler.post(locationUpdater);
    }

    // ================= SMOOTH ANIMATION =================

    private void animateMarker(Marker marker, LatLng newPosition) {

        LatLng startPosition = marker.getPosition();

        ValueAnimator animator = ValueAnimator.ofFloat(0, 1);
        animator.setDuration(1000);
        animator.setInterpolator(new LinearInterpolator());

        animator.addUpdateListener(animation -> {

            float fraction = animation.getAnimatedFraction();

            double lat = fraction * newPosition.latitude +
                    (1 - fraction) * startPosition.latitude;

            double lng = fraction * newPosition.longitude +
                    (1 - fraction) * startPosition.longitude;

            LatLng updatedPosition = new LatLng(lat, lng);
            marker.setPosition(updatedPosition);
        });

        animator.start();
    }

    // ================= SNAP TO ROUTE =================

    private LatLng getNearestPoint(LatLng gpsPoint) {

        if (routeList.isEmpty()) return gpsPoint;

        LatLng nearest = gpsPoint;
        double minDistance = Double.MAX_VALUE;

        for (LatLng routePoint : routeList) {

            double distance = distanceBetween(gpsPoint, routePoint);

            if (distance < minDistance) {
                minDistance = distance;
                nearest = routePoint;
            }
        }

        return nearest;
    }

    private double distanceBetween(LatLng p1, LatLng p2) {

        double earthRadius = 6371000;

        double dLat = Math.toRadians(p2.latitude - p1.latitude);
        double dLng = Math.toRadians(p2.longitude - p1.longitude);

        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(p1.latitude)) *
                        Math.cos(Math.toRadians(p2.latitude)) *
                        Math.sin(dLng/2) * Math.sin(dLng/2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return earthRadius * c;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (locationUpdater != null) {
            handler.removeCallbacks(locationUpdater);
        }
    }
}