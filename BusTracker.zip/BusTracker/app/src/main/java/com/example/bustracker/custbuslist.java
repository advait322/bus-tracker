package com.example.bustracker;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class custbuslist extends AppCompatActivity {

    LinearLayout busContainer;
    DatabaseReference databaseReference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_custbuslist);

        busContainer = findViewById(R.id.busContainer);
        databaseReference = FirebaseDatabase.getInstance().getReference("hostdata");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                busContainer.removeAllViews(); // Clear old views

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                    String from = dataSnapshot.child("from_location").getValue(String.class);
                    String to = dataSnapshot.child("to_location").getValue(String.class);
                    String date = dataSnapshot.child("date").getValue(String.class);
                    String bus = dataSnapshot.child("bus").getValue(String.class);
                    String bus50 = dataSnapshot.child("bus50").getValue(String.class);
                    String bus_seri = dataSnapshot.child("bus_seri").getValue(String.class);
                    String bus0809 = dataSnapshot.child("bus0809").getValue(String.class);

                    if (TextUtils.isEmpty(from) ||
                            TextUtils.isEmpty(to) ||
                            TextUtils.isEmpty(date) ||
                            TextUtils.isEmpty(bus)) {
                        continue;
                    }

                    String busNumber = bus;
                    if (!TextUtils.isEmpty(bus50)) busNumber += " " + bus50;
                    if (!TextUtils.isEmpty(bus_seri)) busNumber += " " + bus_seri;
                    if (!TextUtils.isEmpty(bus0809)) busNumber += " " + bus0809;

                    // Create CardView
                    CardView card = new CardView(custbuslist.this);
                    card.setRadius(16);
                    card.setCardElevation(8);

                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );
                    params.setMargins(0, 0, 0, 30);
                    card.setLayoutParams(params);

                    // Create TextView inside card
                    TextView tv = new TextView(custbuslist.this);
                    tv.setText(
                            "Bus No: " + busNumber + "\n" +
                                    "From: " + from + "\n" +
                                    "To: " + to + "\n" +
                                    "Time: " + date
                    );
                    tv.setTextSize(18);
                    tv.setPadding(30, 30, 30, 30);

                    card.addView(tv);
                    busContainer.addView(card);
                }

                if (busContainer.getChildCount() == 0) {
                    TextView empty = new TextView(custbuslist.this);
                    empty.setText("No valid bus data available");
                    empty.setTextSize(18);
                    busContainer.addView(empty);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(custbuslist.this, "Failed to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
