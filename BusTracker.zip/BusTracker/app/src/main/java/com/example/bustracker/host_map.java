package com.example.bustracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.*;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class host_map extends AppCompatActivity implements OnMapReadyCallback {

    private static final int FINE_PERMISSION_CODE = 1;

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;

    private Marker liveMarker;
    private Marker startMarker;
    private Marker endMarker;

    private Polyline polyline;
    private List<LatLng> routePoints = new ArrayList<>();

    private boolean isFirstPoint = true;
    private boolean tripFinished = false;

    String userId;
    DatabaseReference databaseReference;

    EditText latitute, longitude;
    Button finishBtn, clearBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_map);

        latitute = findViewById(R.id.latitute);
        longitude = findViewById(R.id.longitude);
        finishBtn = findViewById(R.id.finishTrip);
        clearBtn = findViewById(R.id.clearRoute);

        userId = getIntent().getStringExtra("BATCH_NO");

        if (userId == null) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                userId = user.getUid();
            } else {
                Toast.makeText(this, "User not logged in", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
        }

        databaseReference = FirebaseDatabase.getInstance()
                .getReference("hostdata")
                .child(userId);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        createLocationRequest();
        createLocationCallback();

        finishBtn.setOnClickListener(v -> finishRoute());
        clearBtn.setOnClickListener(v -> clearRoute());
    }

    // ---------------- MAP READY ----------------

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);

        mMap.setOnMapClickListener(latLng -> {

            if (tripFinished) return;

            routePoints.add(latLng);

            if (isFirstPoint) {
                isFirstPoint = false;

                startMarker = mMap.addMarker(
                        new MarkerOptions().position(latLng).title("Start Point")
                );

                savePoint("start", latLng);
            }

            if (polyline == null) {
                polyline = mMap.addPolyline(
                        new PolylineOptions()
                                .addAll(routePoints)
                                .width(8f)
                );
            } else {
                polyline.setPoints(routePoints);
            }

            saveRoutePoint(latLng);
        });
    }

    // ---------------- FINISH ROUTE ----------------

    private void finishRoute() {
        if (routePoints.size() == 0 || tripFinished) return;

        tripFinished = true;

        LatLng lastPoint = routePoints.get(routePoints.size() - 1);

        endMarker = mMap.addMarker(
                new MarkerOptions().position(lastPoint).title("End Point")
        );

        savePoint("end", lastPoint);

        Toast.makeText(this, "Route Saved Successfully", Toast.LENGTH_SHORT).show();
    }

    // ---------------- CLEAR ROUTE ----------------

    private void clearRoute() {

        // 1️⃣ Clear from Firebase
        databaseReference.child("start").removeValue();
        databaseReference.child("end").removeValue();
        databaseReference.child("route").removeValue();

        // 2️⃣ Clear map
        if (startMarker != null) startMarker.remove();
        if (endMarker != null) endMarker.remove();
        if (polyline != null) polyline.remove();

        routePoints.clear();
        polyline = null;
        startMarker = null;
        endMarker = null;

        isFirstPoint = true;
        tripFinished = false;

        Toast.makeText(this, "Route Cleared Successfully", Toast.LENGTH_SHORT).show();
    }

    // ---------------- SAVE METHODS ----------------

    private void savePoint(String type, LatLng latLng) {
        Map<String, Object> map = new HashMap<>();
        map.put("latitude", latLng.latitude);
        map.put("longitude", latLng.longitude);
        databaseReference.child(type).setValue(map);
    }

    private void saveRoutePoint(LatLng latLng) {
        Map<String, Object> map = new HashMap<>();
        map.put("latitude", latLng.latitude);
        map.put("longitude", latLng.longitude);
        databaseReference.child("route").push().setValue(map);
    }

    // ---------------- LIVE LOCATION ----------------

    private void createLocationRequest() {
        locationRequest = new LocationRequest.Builder(1000)
                .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                .build();
    }

    private void createLocationCallback() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {

                if (locationResult == null) return;

                Location location = locationResult.getLastLocation();
                if (location == null) return;

                double lat = location.getLatitude();
                double lng = location.getLongitude();

                LatLng liveLatLng = new LatLng(lat, lng);

                if (liveMarker == null) {
                    liveMarker = mMap.addMarker(
                            new MarkerOptions()
                                    .position(liveLatLng)
                                    .title("Live Bus Location")
                    );
                } else {
                    liveMarker.setPosition(liveLatLng);
                }

                Map<String, Object> liveMap = new HashMap<>();
                liveMap.put("latitude", lat);
                liveMap.put("longitude", lng);

                databaseReference.updateChildren(liveMap);

                latitute.setText(String.valueOf(lat));
                longitude.setText(String.valueOf(lng));
            }
        };
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    FINE_PERMISSION_CODE);
            return;
        }

        fusedLocationProviderClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == FINE_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}