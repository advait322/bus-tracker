package com.example.bustracker;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class first_page extends AppCompatActivity {

    ImageView logo;
    ProgressBar progressBar;
    int progress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_first_page);

        logo = findViewById(R.id.logo);
        progressBar = findViewById(R.id.progressBar);

        // NEW: Bus running animation
        try {
            Animation moveBus = AnimationUtils.loadAnimation(this, R.anim.bus_move);
            logo.startAnimation(moveBus);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Handler handler = new Handler(Looper.getMainLooper());

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                progress++;
                progressBar.setProgress(progress);

                if (progress < 100) {
                    handler.postDelayed(this, 30);
                } else {
                    Intent intent = new Intent(first_page.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }, 40);
    }
}
