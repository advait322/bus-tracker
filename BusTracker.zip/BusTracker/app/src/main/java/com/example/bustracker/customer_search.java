package com.example.bustracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.*;

public class customer_search extends AppCompatActivity {

    TextView userInfoText;
    EditText from_location, to_location;
    Button searchBtn, buslist;
    LinearLayout resultLayout;

    DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);

        // 🔹 If not logged in → go to login
        if (!sharedPreferences.getBoolean("isLoggedIn", false)) {
            startActivity(new Intent(this, customer_login.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_customer_search);

        userInfoText = findViewById(R.id.user_info_text);
        from_location = findViewById(R.id.from_location);
        to_location = findViewById(R.id.to_location);
        searchBtn = findViewById(R.id.search_buses_button);
        buslist = findViewById(R.id.buslist);
        resultLayout = findViewById(R.id.resultLayout);

        databaseReference = FirebaseDatabase.getInstance().getReference("hostdata");

        ImageButton profileBtn = findViewById(R.id.profile_button);
        CardView userCard = findViewById(R.id.userCard);
        Button logoutBtn = findViewById(R.id.logout_button);

        // 🔹 Get user info from SharedPreferences
        String userId = sharedPreferences.getString("USER_ID", "");
        String name = sharedPreferences.getString("NAME", "");
        String mobile = sharedPreferences.getString("MOBILE", "");

        userInfoText.setText(
                "User ID: " + userId +
                        "\nName: " + name +
                        "\nMobile: " + mobile
        );

        profileBtn.setOnClickListener(v -> {
            if (userCard.getVisibility() == View.GONE)
                userCard.setVisibility(View.VISIBLE);
            else
                userCard.setVisibility(View.GONE);
        });

        logoutBtn.setOnClickListener(v -> {

            // ✅ CLEAR SESSION
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();

            Intent intent =
                    new Intent(customer_search.this,
                            MainActivity.class);

            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
        });

        searchBtn.setOnClickListener(v -> searchBus());

        buslist.setOnClickListener(v ->
                startActivity(new Intent(this, custbuslist.class))
        );
    }

    private void searchBus() {

        String from = from_location.getText().toString().trim();
        String to = to_location.getText().toString().trim();

        if (TextUtils.isEmpty(from) || TextUtils.isEmpty(to)) {
            Toast.makeText(this,
                    "Enter From and To location",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        resultLayout.removeAllViews();

        databaseReference.addListenerForSingleValueEvent(
                new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        boolean busFound = false;

                        for (DataSnapshot dataSnapshot :
                                snapshot.getChildren()) {

                            String busId = dataSnapshot.getKey();
                            String dbFrom =
                                    dataSnapshot.child("from_location")
                                            .getValue(String.class);
                            String dbTo =
                                    dataSnapshot.child("to_location")
                                            .getValue(String.class);
                            String dbDate =
                                    dataSnapshot.child("date")
                                            .getValue(String.class);
                            String bus =
                                    dataSnapshot.child("bus")
                                            .getValue(String.class);

                            if (dbFrom == null || dbTo == null)
                                continue;

                            if (dbFrom.equalsIgnoreCase(from) &&
                                    dbTo.equalsIgnoreCase(to)) {

                                busFound = true;

                                TextView tv =
                                        new TextView(customer_search.this);

                                tv.setText(
                                        "Bus No: " + bus +
                                                "\nFrom: " + dbFrom +
                                                "\nTo: " + dbTo +
                                                "\nTime: " + dbDate
                                );

                                tv.setPadding(0, 25, 0, 10);

                                Button trackBtn =
                                        new Button(customer_search.this);

                                trackBtn.setText("Track");

                                trackBtn.setOnClickListener(view -> {

                                    Intent intent =
                                            new Intent(customer_search.this,
                                                    TrackBus.class);

                                    intent.putExtra("BUS_ID", busId);
                                    startActivity(intent);
                                });

                                resultLayout.addView(tv);
                                resultLayout.addView(trackBtn);
                            }
                        }

                        if (!busFound) {
                            TextView tv =
                                    new TextView(customer_search.this);

                            tv.setText("Bus is not available");
                            tv.setTextSize(18);
                            tv.setPadding(0, 40, 0, 0);
                            resultLayout.addView(tv);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
    }
}