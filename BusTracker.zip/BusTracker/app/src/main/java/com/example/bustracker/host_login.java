package com.example.bustracker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class host_login extends AppCompatActivity {

    // UI Elements
    EditText batchno, mobile, password;
    Button host_loginButton;

    // Firebase Database reference
    DatabaseReference databaseReference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_login);

        databaseReference = FirebaseDatabase.getInstance().getReference("hostdata");

        batchno = findViewById(R.id.batchno);
        mobile = findViewById(R.id.mobile);
        password = findViewById(R.id.password);
        host_loginButton = findViewById(R.id.host_login);

        host_loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });
    }

    private void loginUser() {
        final String batchFromInput = batchno.getText().toString().trim();
        final String mobileFromInput = mobile.getText().toString().trim();
        final String passwordFromInput = password.getText().toString().trim();

        if (TextUtils.isEmpty(batchFromInput) || TextUtils.isEmpty(mobileFromInput) || TextUtils.isEmpty(passwordFromInput)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Query checkUserQuery = databaseReference.orderByChild("batch_no").equalTo(batchFromInput);

        checkUserQuery.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String passwordFromDB = userSnapshot.child("password").getValue(String.class);
                        String mobileFromDB = userSnapshot.child("mobile").getValue(String.class);

                        if (passwordFromDB != null && passwordFromDB.equals(passwordFromInput) && mobileFromDB != null && mobileFromDB.equals(mobileFromInput)) {

                            Toast.makeText(host_login.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(host_login.this, host_bus_no.class);
                            // --- Add the batch number to the Intent ---
                            String userId = userSnapshot.getKey();
                            intent.putExtra("BATCH_NO", userId);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            return;
                        }
                    }
                    Toast.makeText(host_login.this, "Invalid Credentials (Wrong Mobile or Password)", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(host_login.this, "User not found (Wrong Batch Number)", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(host_login.this, "Database Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                Log.e("FirebaseError", "onCancelled", error.toException());
            }
        });
    }
}
